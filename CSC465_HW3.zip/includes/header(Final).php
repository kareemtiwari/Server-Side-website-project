<!DOCTYPE html>
<html lang="en">


<head>
<div class="navbar-collapse collapse">
            <ul class="nav navbar-nav navbar-right">
                <li class="active"><a href="index">Home</a></li>                    
                <li><a href="#">Home</a></li>
                <li><a href="#">Create Account</a></li>
                <li><a href="#">About Us</a></li>
                <li><a href="#">Upload Pix</a></li>
                <li><a href="#">Contact Us</a></li>
            </ul>
        </div>
</head>
<body>
<header>
<h1>Family Frame</h1>
</header>
