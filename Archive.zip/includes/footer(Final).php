<!DOCTYPE html>

<footer>
  <p> Email: theFamilyFrame@hotmail.com  Phone: 1-800-456-8876</p>
  <p> &copy; 2022 Kareem Tiwari </p>
  
  </footer>