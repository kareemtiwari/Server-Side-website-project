
<!DOCTYPE html>

<html lang="en">
<head>
<?php 
include('includes/header(Final).php');
?>
   <img src="Images/TransparentFF.png" alt="FAM Logo">
    <h2> </h2>
  </header>
  
  <section>

  <h2>Mission Statement</h2>
  <p>The FamilyFrame is all about bringing family together. With FamilyFrame its becoming easier and easier to never miss the special moments captured even when your not there. Just login, upload your photo and or video , and enjoy the memories. <p>
  </section>
  
  <footer>
  <?php
 include('includes/footer(Final).php');
 ?>
  </footer>
  </body>
</html>




